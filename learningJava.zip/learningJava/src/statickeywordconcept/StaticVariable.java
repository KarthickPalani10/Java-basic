package statickeywordconcept;

public class StaticVariable {
    //Example to show,Static variable are share among objects.
    static int accountBalance = 0;
    String depositeBy;

    public static void main(String[] args) {
        StaticVariable object1 = new StaticVariable();
        object1.accountBalance=1000;
        object1.depositeBy="karthick";
        StaticVariable object2 = new StaticVariable();
        object2.accountBalance=3000;
        object2.depositeBy="kumaravel";
        StaticVariable object3 = new StaticVariable();
        object3.accountBalance=4000;
        object3.depositeBy="Mani";

        System.out.println("object integer " +object1.accountBalance);
        System.out.println("object integer " +object1.depositeBy);
        System.out.println("object integer " +object2.accountBalance);
        System.out.println("object integer " +object2.depositeBy);
        System.out.println("object integer " +object3.accountBalance);
        System.out.println("object integer " +object3.depositeBy);



    }
}
