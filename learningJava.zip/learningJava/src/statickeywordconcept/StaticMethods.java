package statickeywordconcept;

public class StaticMethods {
    // Create a static method and call it without object.
    public static void method1(){
        System.out.println("Static method");
    }
    //we can call Static method from non static method but not otherwise.
    public  void method2(){
        System.out.println("Non Static method");//StaticMethods name = new StaticMethods();name.method2();call this
    }
    public static void main(String[] args) {
        method1();

    }
}

