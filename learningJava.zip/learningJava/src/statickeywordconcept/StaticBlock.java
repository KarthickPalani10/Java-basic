package statickeywordconcept;

public class StaticBlock {
    // when u create the static {} first static will execution in order.order by order execution.
    static {
        System.out.println("Inside static block1");
    }
    //priority first static and main method it's logic......
    static {
        System.out.println("Inside static block2");
    }
    public static void main(String[] args) {
            System.out.println("Inside main method");
        }
    }

