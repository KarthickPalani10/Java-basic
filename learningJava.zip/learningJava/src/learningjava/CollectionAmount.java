package learningjava;
//reture Type leaning Explanation
public class CollectionAmount {
    Long collectAmount = 1000l;
    int collectAmount2 = 1225;
    //A Return Statement cause the program control to transfer back the caller of a method
    public int collectAmountAndGiveItToMe(){
        System.out.println("Daddy have colleted amount "+collectAmount2 + " and send it to you");
        return collectAmount2;//
    }
    public static void main(String[] args) {
        CollectionAmount mySon = new CollectionAmount();
        int amount = mySon.collectAmountAndGiveItToMe();
        System.out.println("Got the amount My Son " + amount);
    }

}
