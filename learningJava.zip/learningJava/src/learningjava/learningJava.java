package learningjava;

public class learningJava {
    String name;

    public void st() {
        String st = "hello";
        System.out.println("It is a "+ st);
    }

    public static void main(String[] args) {
        learningJava first = new learningJava();
        first.st();

    }


    }





