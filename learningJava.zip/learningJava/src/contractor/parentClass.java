package contractor;

public class parentClass {

    public parentClass() {
        System.out.println("Parent class");
    }

}
