package contractor;

public class ChildClass extends parentClass{

    public ChildClass(){
        System.out.println("child constructor");
    }

    public static void main(String[] args) {
        ChildClass childClass = new ChildClass();


    }
}
