package contractor;

public class Draw {
    //over loading
   Draw(){
        System.out.println("Draw the object");
    }// having only parameterized constructor and calling no arg constructor. got error /* ***  */
    Draw(String toDraw){
         String draw = toDraw;
        System.out.println("drawing to "+toDraw);
    }

    public static void main(String[] args) {
        Draw draw= new Draw();
        Draw draw1= new Draw("circle");

    }

}

