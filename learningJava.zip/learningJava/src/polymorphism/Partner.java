package polymorphism;

public class Partner {
    // *This class is to illustration method overloading with a practical example
}
