package polymorphism;

public class TheWayWeTake {
    // we can create Parent class,Partner class,Boss class.
    // *This class is to illustration method overloading with a practical example.
    // it's called as method overloading. method name should be same. Must imp
    public void take(Parents styleOfTaking){
        System.out.println("Polite , Respectable ??");
    }
    public void take(Partner styleOfTaking){
        System.out.println("love, Romantic, Mixture of everything!!");
    }
    public  void take(Boss StyleOfTaking){
        System.out.println("Nothing personal");
    }
    public static void main(String[] args) {
        TheWayWeTake take = new TheWayWeTake();
        Parents parents = new Parents();
        take.take(parents);
        Partner partner = new Partner();
        take.take(partner);
        Boss boss = new Boss();
        take.take(boss);
}
}
