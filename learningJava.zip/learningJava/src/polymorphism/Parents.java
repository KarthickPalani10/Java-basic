package polymorphism;

public class Parents {
    /*This class is to illustration method overloading with a practical example.Also it acts as the demostrate
    Overriding */
    public void properties(){
        System.out.println("Son!! use my property");
    }
    public void marriage(){
        System.out.println("Son !! Marry your Uncle's doughter");
    }

}
