package polymorphism;

public class Son extends Parents{
    //This Class is to illustrate method overriding with a practical Example...
    // When child class not satisfying with the implementation of parent class @Override come in child class.
@Override
public void marriage(){
    System.out.println("My Marriage MY Rule....");
}
    public static void main(String[] args) {
        Parents parents = new Son();// syntax: parentClass ref = new childClass
        parents.properties();
        parents.marriage();

    }
}

