package polymorphism;

public class Boss {
    // *This class is to illustration method overloading with a practical example
}
