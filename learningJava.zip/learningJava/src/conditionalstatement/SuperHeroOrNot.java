package conditionalstatement;

public class SuperHeroOrNot {
    //Switch case we will use the multiple condition
    String hero = "Iron man";

    public void heroOrNot(){
        switch (hero){
            case "Iron man":
                System.out.println("Iron man is a super hero");
                break;
            case "bat man":
                System.out.println("bat man is a super hero");
                break;
            case "super man":
                System.out.println("super man is a super hero");
                break;
            default:
                System.out.println(hero + "Sorry I don't know this person");
        }
    }
    public static void main(String[] args) {
        SuperHeroOrNot hero = new SuperHeroOrNot();
        hero.heroOrNot();
    }
}
