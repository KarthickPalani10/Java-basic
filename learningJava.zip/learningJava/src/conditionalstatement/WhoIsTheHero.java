package conditionalstatement;

public class WhoIsTheHero {
    String myHeroName = "Super man";//Super Man print--> Sorry i can't guess we will use
    public void superHeroGuesser(){
        if(myHeroName.equals("iron man")){
            System.out.println("Your thought about Iron man");
        }else if(myHeroName.equals("Super man")){//equalsIgnorcase/ Super MAN the will print super man
            System.out.println("Your thought about Super man");
        } else if (myHeroName.equals("Thor")){
            System.out.println("Your thought about Thor");
        }else {
            System.out.println("Sorry i can't guess");
        }
    }
    public static void main(String[] args) {
        WhoIsTheHero hero = new WhoIsTheHero();
        hero.superHeroGuesser();
    }
    }
