package conditionalstatement;

public static class LetsHaveACoffe {
    //boolean is data type YES OR NO
    boolean isCupEmpty = true;//change the vale is false print else statement

    public static void main(String[] args) {
        LetsHaveACoffe coffe = new LetsHaveACoffe();
        if(coffe.isCupEmpty){
            System.out.println("Fill the cup");
        }
        else{
            System.out.println("Drink the coffee");
        }
    }
}
