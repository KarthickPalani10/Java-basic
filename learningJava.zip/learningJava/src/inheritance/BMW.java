package inheritance;

public class BMW extends Car{
    public static void main(String[] args) {
        BMW bmw = new BMW();
        bmw.engine();

    }
}
/*Access modifiers-Same class-Same package-Sub/class-Other class
Public            -    Y     -     Y      -    Y    -     Y
protected         -    Y     -     Y      -    Y    -     N
no access modifer -    Y     -     Y      -    N    -     N
private           -    Y     -     N      -    N    -     N
 */