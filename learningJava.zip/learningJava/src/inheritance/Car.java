package inheritance;// Meaning reusability of code use parent and child.

public class Car {
    //Process of acquiring the properties(data +methods) we can use multiple class and data and method

    public int wheels=4;//default int wheels, Private int wheels,
    public void engine(){
        System.out.println("This my engine secret");
    }
    public static void main(String[] args) {
        Car car = new Car();
        car.engine();
    }
}
/*Access Modifiers:
* default - When No acess modifier is specified. EX code :int wheels
* Private - only within the class in which they are declared. EX code:private int wheels
* Protected - with same package/sub Class in difference package.EX code:protected int wheels
* Public - from everywhere in the program. EX code:Public int wheels
 */

